package br.com.unieventos.application;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.InputMismatchException;

import br.com.unieventos.DAO.AtividadeDAO;
import br.com.unieventos.DAO.EventoDAO;
import br.com.unieventos.DAO.ParticipanteDAO;
import br.com.unieventos.modelo.Atividade;
import br.com.unieventos.modelo.CadastroDeAtividade;
import br.com.unieventos.modelo.CadastroDeEvento;
import br.com.unieventos.modelo.CadastroDeParticipante;
import br.com.unieventos.modelo.ConfirmaParticipacao;
import br.com.unieventos.modelo.Evento;
import br.com.unieventos.modelo.Feira;
import br.com.unieventos.modelo.MesaRedonda;
import br.com.unieventos.modelo.Minicurso;
import br.com.unieventos.modelo.Palestra;
import br.com.unieventos.modelo.Participante;

public class AppMainConsole {

	private static final Screen SCREEN = new Screen();
	private static final Keypad KEYPAD = new Keypad();
	private static final String EVENTO = "E";
	private static final String INTERESSADO = "I";
	private static final String RESPONSAVEL_ATIVIDADE = "CR";
	private static final String PARTICIPACAO = "CP";
	private static final String ESTATISTICA_ATIVIDADE = "EA";
	private static final String ESTATISTICA_EVENTO = "EE";
	private static final String SAIR = "S";

	public static void main(String[] args) {

		//Descomente o inicializaBancoDeDados() para ter os dados da estat�stica
		//inicializaBancoDeDados();

		while (true) {

			displayMainMenu();
			String escolha = "";
			escolha = KEYPAD.getInputString().toUpperCase();

			switch (escolha) {
			case EVENTO:
				servicoCadastroDeEvento();
				break;
			case INTERESSADO:
				servicoInscricaoDeInteressado();
				break;
			case RESPONSAVEL_ATIVIDADE:
				servicoCadastroDeAtividadeResponsavel();
				break;
			case PARTICIPACAO:
				servicoDeConfirmacaoDeParticipacao();
				break;
			case ESTATISTICA_ATIVIDADE:
				servicoEstatisticaAtividade();
				break;
			case ESTATISTICA_EVENTO:
				servicoEstatisticaEvento();
				break;
			case SAIR:
				sair();
				break;
			}
		}
	}

	public static void displayMainMenu() {

		SCREEN.displayMessageLine("\nMenu principal:");
		SCREEN.displayMessageLine("\nE  - Evento");
		SCREEN.displayMessageLine("I  - Inscreva-se");
		SCREEN.displayMessageLine("CR - Cadastra Atividade e seu Respons�vel");
		SCREEN.displayMessageLine("CP - Confirmar Participa��o");
		SCREEN.displayMessageLine("EA - Estat�stica por Atividade");
		SCREEN.displayMessageLine("EE - Estat�stica por Evento");
		SCREEN.displayMessageLine("S - Sair");
		SCREEN.displayMessage("\nEscolha uma op��o:");
	}

	public static void servicoCadastroDeEvento() {
		jumpLines();
		SCREEN.displayMessage("\tCADASTRO DE EVENTO\n");
		CadastroDeEvento evento = new CadastroDeEvento();
		evento.cadastra();
	}

	public static void inicializaBancoDeDados() {

		
		Evento eventoU = new Evento("TJ", "Food", "Food", "Joana e Cassandra");
		Evento eventoF= new Evento("KO", "IA", "Tecnologia", "Pedro");
		Evento eventoJ = new Evento("JDK", "Java", "Linguagem", "Junior");
		
		EventoDAO eventoDao = new EventoDAO();
		eventoDao.cadastra(eventoJ);
		eventoDao.cadastra(eventoF);
		eventoDao.cadastra(eventoU);
		
		Feira feira = new Feira("Gastronomia Unieventos", "Juninor, Pedro e Cassandra");
		feira.setEvento(eventoU);
		MesaRedonda mesa = new MesaRedonda("Chuva de ideiais", "Carlos e Sabrina");
		mesa.setEvento(eventoF);
		Minicurso minicurso = new Minicurso("Business Inteligence", "Miguel");
		minicurso.setLimiteParticipante(4);
		minicurso.setEvento(eventoJ);
		
		AtividadeDAO atividade = new AtividadeDAO();
		atividade.cadastra(feira);
		atividade.cadastra(mesa);
		atividade.cadastra(minicurso);

		Participante mylena = new Participante("Mylena", "mila@gmail.com");
		mylena.setParticipou(true);
		mylena.setAtividade(feira, mylena);
		Participante odilon = new Participante("Odilon", "odilon@gmail.com");
		odilon.setAtividade(mesa, odilon);
		Participante valdenilson = new Participante("Valdenilson", "valdenilson@gmail.com");
		valdenilson.setAtividade(minicurso, valdenilson);
		valdenilson.setParticipou(true);
		Participante manasses = new Participante("Manass�s", "manasses@gmail.com");
		manasses.setAtividade(minicurso, manasses);

		ParticipanteDAO participanteDao = new ParticipanteDAO();
		participanteDao.cadastra(manasses);
		participanteDao.cadastra(mylena);
		participanteDao.cadastra(odilon);
		participanteDao.cadastra(valdenilson);

		SCREEN.displayMessage("Banco de dados inicializado com sucesso!\n");
	}

	public static void servicoInscricaoDeInteressado() {

		jumpLines();

		CadastroDeParticipante cadastraParticipante = new CadastroDeParticipante();
		cadastraParticipante.cadastra();

		jumpLines();
	}

	public static void servicoCadastroDeAtividadeResponsavel() {

		// Pula linhas para n�o poluir a tela
		jumpLines();
		
		// Cria um objeto para cadastrar as atividades
		CadastroDeAtividade cadastraAtividade = new CadastroDeAtividade();

		// Vari�veis para facilitar a leitura
		final String feira = "FE";
		final String mesaRedonda = "MR";
		final String minicurso = "MI";
		final String palestra = "PA";

		// Vari�vel para escolha
		String escolha;
		// Vari�vel que continua o loop caso o usu�rio n�o digite a atividade desejada
		boolean continuaLoop = true;

		do {
			menuAtividadesDisponiveis();

			SCREEN.displayMessage("\nEscolha uma atividade:");
			escolha = KEYPAD.getInputString().toUpperCase();

			switch (escolha) {
			case feira:
				Feira CFeira = new Feira();
				cadastraAtividade.cadastra(CFeira);
				continuaLoop = false;
				break;
			case mesaRedonda:
				MesaRedonda CMesaRedonda = new MesaRedonda();
				cadastraAtividade.cadastra(CMesaRedonda);
				continuaLoop = false;
				break;
			case minicurso:
				Minicurso CMinicurso = new Minicurso();
				cadastraAtividade.cadastra(CMinicurso);
				continuaLoop = false;
				break;
			case palestra:
				Palestra CPalestra = new Palestra();
				cadastraAtividade.cadastra(CPalestra);
				continuaLoop = false;
				break;
			}
		} while (continuaLoop);

		SCREEN.displayMessageLine("\nCadastrado com sucesso! Pressione Enter para continuar\n");
		KEYPAD.getInputString();
		KEYPAD.getInputString();
		jumpLines();
	}

	private static void menuAtividadesDisponiveis() {

		SCREEN.displayMessageLine("\nAtividades dispon�veis:");
		SCREEN.displayMessageLine("\nFE - Feira");
		SCREEN.displayMessageLine("MR - Mesa Redonda");
		SCREEN.displayMessageLine("MI - Minicurso");
		SCREEN.displayMessageLine("PA - Palestra");
	}

	public static void servicoDeConfirmacaoDeParticipacao() {
		ConfirmaParticipacao confirmaP = new ConfirmaParticipacao();
		confirmaP.confirma();
	}

	public static void servicoEstatisticaAtividade() {
		
		AtividadeDAO atividadeDao = new AtividadeDAO();
		ArrayList<Atividade> atividades = (ArrayList<Atividade>) atividadeDao.recuperaTodasAtividades();
		SCREEN.displayMessageLine("Atividades dispon�veis para a quantidade de participantes:\n");
		
		for (int i = 0; i < atividades.size(); i++) {
			SCREEN.displayMessageLine(atividades.get(i).getNome() + ", c�digo: " + i);
		}
		
		SCREEN.displayMessage("\nEscolha uma atividade pelo c�digo: ");
		
		//Trata a entrada de um inteiro
		Integer escolhaAtividade = 0;
		ArrayList<BigInteger> qtdInscritos = null;
		boolean continuaLoop = true;
		
		do {
			try {
				
				escolhaAtividade = KEYPAD.getInputInteiro();
				qtdInscritos = (ArrayList<BigInteger>) atividadeDao.quantidadeInscritos(escolhaAtividade + 1);
				continuaLoop = false;
				
			} catch (InputMismatchException e) {
				SCREEN.displayMessage("Entrada inv�lida! Tente novamente com um n�mero:");
				KEYPAD.getInputString();
			} catch (IndexOutOfBoundsException  e) {
				SCREEN.displayMessage("Atividade n�o encontrada! tente novamente:");
				KEYPAD.getInputString();
			}
		} while (continuaLoop);
		
		SCREEN.displayMessage("Total de inscritos nesta atividade: " + qtdInscritos.get(0).intValue());
		KEYPAD.getInputString();
		KEYPAD.getInputString();
		
		SCREEN.displayMessage("");
		
		SCREEN.displayMessageLine("Atividades dispon�veis para a lista de participantes:\n");
		
		for (int i = 0; i < atividades.size(); i++) {
			SCREEN.displayMessageLine(atividades.get(i).getNome() + ", c�digo: " + i);
		}
		

		SCREEN.displayMessage("\nEscolha uma atividade pelo c�digo para a lista de inscritos: ");
		
		//Trata a entrada de um inteiro
		Integer escolhaAtividade1 = 0;
		boolean continuaLoop1 = true;
		ArrayList<Participante> participantes = new ArrayList<>();
		 
		do {
			try {
				
				escolhaAtividade1 = KEYPAD.getInputInteiro();
				participantes = (ArrayList<Participante>) atividadeDao.listaDeInscritosPorAtividade(escolhaAtividade1+1);
				continuaLoop1 = false;
				
			} catch (InputMismatchException e) {
				SCREEN.displayMessage("Entrada inv�lida! Tente novamente com um n�mero:");
				KEYPAD.getInputString();
			} catch (IndexOutOfBoundsException  e) {
				SCREEN.displayMessage("Atividade n�o encontrada! tente novamente:");
				KEYPAD.getInputString();
			}
		} while (continuaLoop1);
		
		for (int i = 0; i < participantes.size(); i++) {
			System.out.println(participantes.get(i).toString());
		}
		
	}

	public static void servicoEstatisticaEvento() {

	}

	public static void sair() {
		System.out.println("Tchau tchau!");
		System.exit(0);
	}

	public static void jumpLines() {
		for (int i = 0; i < 50; i++) {
			SCREEN.displayMessageLine("");
		}
	}
}
