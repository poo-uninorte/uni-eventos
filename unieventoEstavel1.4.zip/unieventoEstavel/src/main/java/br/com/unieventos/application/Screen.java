package br.com.unieventos.application;

public class Screen {
	
	public void displayMessage( String mensagem) {
		System.out.print(mensagem);
	}
	
	public void displayMessageLine( String mensagem) {
		System.out.println(mensagem);
	}
	
	public void displayMessageNumberLine( long mensagem) {
		System.out.println(mensagem);
	}
}
