package br.com.unieventos.teste;

import java.util.ArrayList;

import org.junit.Test;

import br.com.unieventos.DAO.AtividadeDAO;
import br.com.unieventos.modelo.Atividade;
import br.com.unieventos.modelo.Participante;

public class TestaEvento {

	@Test
	public void testsEvento() {
		
		
		AtividadeDAO atividadeDao = new AtividadeDAO();
		ArrayList<?> atividades = (ArrayList<?>) atividadeDao.listaDeInscritosPorAtividade(1);
		
		System.out.println(atividades.toString());
		
		for (int i = 0; i < atividades.size(); i++) {
			System.out.println(atividades.get(i).toString());
		}
		
		
		
		
		
//		
//		AtividadeDAO atividd = new AtividadeDAO();
//		ArrayList<BigInteger> query = (ArrayList<BigInteger>) atividd.quantidadeInscritos(3);
//		
//		BigInteger qtd = query.get(0);
//		
//		System.out.println(qtd);
//		
//		AtividadeDAO atv = new AtividadeDAO();
//		ArrayList<Integer> limite = (ArrayList<Integer>) atv.quantidadeLimiteDaAtividade(3);
//		
//		Integer limiteA = limite.get(0);
//		
//		System.out.println(limiteA);
		
		
//		boolean maior = qtd.intValue() > 3;
//		
//		System.out.println(maior);
//		
//		System.out.println(qtd);
//		
//		for (int i = 0; i < qtd.intValue(); i++) {
//			System.out.println("oi");
//		}
		
		
//		AtividadeDAO atividd = new AtividadeDAO();
//		ArrayList<BigInteger> query = (ArrayList<BigInteger>) atividd.quantidadeLimiteDaAtividade(4);
//		
//		BigInteger limite = query.get(0);
		
		
		
	}
}
